package com.remotehotspot.shared

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Schema:
 *  /pairingCodes/{code}            {deviceId, deviceUid, exp}          written by User
 *  /pairingClaims/{code}           {adminUid}                           written by Admin
 *  /devices/{id}/meta              {deviceUid, owner, token, model, manufacturer, name, btName, fcmToken}
 *  /devices/{id}/status            {battery, charging, hotspot, lastSeen, lastCmd, lastCmdTs}
 *  /commands/{id}/{cmdId}          {cmd, arg, ts, token}                written by Admin
 *  /commandResults/{id}/{cmdId}    {ok, msg, hotspot, ts}               written by User
 *  /admins/{adminUid}/devices/{id} true
 */
class FirebaseRepo {
    private val db = FirebaseDatabase.getInstance().apply { runCatching { setPersistenceEnabled(true) } }
    val auth = FirebaseAuth.getInstance()

    suspend fun uid(): String = auth.currentUser?.uid ?: auth.signInAnonymously().await().user!!.uid
    fun ref(path: String) = db.getReference(path)

    // ---------- Pairing: User side ----------
    suspend fun createPairingCode(deviceId: String, meta: Map<String, Any>): String {
        val me = uid()
        val token = java.util.UUID.randomUUID().toString().replace("-", "")
        val code = (100000..999999).random().toString()
        ref("devices/$deviceId/meta").updateChildren(meta + mapOf("deviceUid" to me, "token" to token)).await()
        ref("pairingCodes/$code").setValue(mapOf("deviceId" to deviceId, "deviceUid" to me,
            "exp" to System.currentTimeMillis() + 10 * 60_000L)).await()
        return code
    }

    /** User listens for an Admin claim; binds owner and returns adminUid. */
    suspend fun awaitClaim(code: String, deviceId: String): String? {
        return withTimeoutOrNull(10 * 60_000L) {
            suspendCancellableCoroutine { cont ->
                val r = ref("pairingClaims/$code")
                val l = object : ValueEventListener {
                    override fun onDataChange(s: DataSnapshot) {
                        val admin = s.child("adminUid").getValue(String::class.java) ?: return
                        r.removeEventListener(this)
                        ref("devices/$deviceId/meta/owner").setValue(admin)
                        r.removeValue(); ref("pairingCodes/$code").removeValue()
                        if (cont.isActive) cont.resume(admin)
                    }
                    override fun onCancelled(e: DatabaseError) { if (cont.isActive) cont.resume(null) }
                }
                r.addValueEventListener(l)
                cont.invokeOnCancellation { r.removeEventListener(l) }
            }
        }
    }

    // ---------- Pairing: Admin side ----------
    /** Claims a code. Returns deviceId once the device confirms ownership, else null. */
    suspend fun claimCode(code: String): String? {
        val me = uid()
        val snap = ref("pairingCodes/$code").get().await()
        val deviceId = snap.child("deviceId").getValue(String::class.java) ?: return null
        if ((snap.child("exp").getValue(Long::class.java) ?: 0) < System.currentTimeMillis()) return null
        ref("pairingClaims/$code").setValue(mapOf("adminUid" to me)).await()
        val ok = withTimeoutOrNull(30_000L) {
            suspendCancellableCoroutine<Boolean> { cont ->
                val r = ref("devices/$deviceId/meta/owner")
                val l = object : ValueEventListener {
                    override fun onDataChange(s: DataSnapshot) {
                        if (s.getValue(String::class.java) == me) { r.removeEventListener(this); if (cont.isActive) cont.resume(true) }
                    }
                    override fun onCancelled(e: DatabaseError) { if (cont.isActive) cont.resume(false) }
                }
                r.addValueEventListener(l); cont.invokeOnCancellation { r.removeEventListener(l) }
            }
        } ?: false
        if (!ok) return null
        ref("admins/$me/devices/$deviceId").setValue(true).await()
        return deviceId
    }

    suspend fun unpair(deviceId: String) {
        val me = uid()
        ref("admins/$me/devices/$deviceId").removeValue().await()
        ref("devices/$deviceId/meta/owner").removeValue().await()
    }

    // ---------- Admin: observe devices ----------
    fun observeDevices(adminUid: String): Flow<List<DeviceInfo>> = callbackFlow {
        val listeners = mutableMapOf<String, Pair<DatabaseReference, ValueEventListener>>()
        val cache = mutableMapOf<String, DeviceInfo>()
        fun push() { trySend(cache.values.sortedBy { it.name.lowercase() }) }
        val idsRef = ref("admins/$adminUid/devices")
        val idsListener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val ids = s.children.mapNotNull { it.key }.toSet()
                (listeners.keys - ids).forEach { id -> listeners.remove(id)?.let { it.first.removeEventListener(it.second) }; cache.remove(id) }
                ids.filter { it !in listeners }.forEach { id ->
                    val r = ref("devices/$id")
                    val l = object : ValueEventListener {
                        override fun onDataChange(d: DataSnapshot) { cache[id] = parse(id, d); push() }
                        override fun onCancelled(e: DatabaseError) {}
                    }
                    listeners[id] = r to l; r.addValueEventListener(l)
                }
                push()
            }
            override fun onCancelled(e: DatabaseError) {}
        }
        idsRef.addValueEventListener(idsListener)
        awaitClose { idsRef.removeEventListener(idsListener); listeners.values.forEach { it.first.removeEventListener(it.second) } }
    }

    private fun parse(id: String, d: DataSnapshot): DeviceInfo {
        val m = d.child("meta"); val s = d.child("status")
        val lastSeen = s.child("lastSeen").getValue(Long::class.java) ?: 0
        val online = System.currentTimeMillis() - lastSeen < ONLINE_WINDOW_MS
        return DeviceInfo(
            deviceId = id, name = m.child("name").getValue(String::class.java) ?: "Device",
            model = m.child("model").getValue(String::class.java) ?: "", manufacturer = m.child("manufacturer").getValue(String::class.java) ?: "",
            battery = s.child("battery").getValue(Int::class.java) ?: -1, charging = s.child("charging").getValue(Boolean::class.java) ?: false,
            hotspot = s.child("hotspot").getValue(Boolean::class.java), lastSeen = lastSeen,
            btName = m.child("btName").getValue(String::class.java) ?: "", token = m.child("token").getValue(String::class.java) ?: "",
            lastCmd = s.child("lastCmd").getValue(String::class.java) ?: "", lastCmdTs = s.child("lastCmdTs").getValue(Long::class.java) ?: 0,
            transport = if (online) Transport.FIREBASE else Transport.OFFLINE
        )
    }

    // ---------- Commands ----------
    /** Admin: push a command and wait for the device's result. */
    suspend fun sendCommand(deviceId: String, c: Command, timeoutMs: Long = 15_000L): Reply? {
        ref("commands/$deviceId/${c.id}").setValue(mapOf("cmd" to c.cmd, "arg" to c.arg, "ts" to c.ts, "token" to c.token)).await()
        return withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<Reply?> { cont ->
                val r = ref("commandResults/$deviceId/${c.id}")
                val l = object : ValueEventListener {
                    override fun onDataChange(s: DataSnapshot) {
                        if (!s.exists()) return
                        r.removeEventListener(this)
                        if (cont.isActive) cont.resume(Reply(c.id, s.child("ok").getValue(Boolean::class.java) ?: false,
                            s.child("msg").getValue(String::class.java) ?: "", s.child("hotspot").getValue(Boolean::class.java)))
                    }
                    override fun onCancelled(e: DatabaseError) { if (cont.isActive) cont.resume(null) }
                }
                r.addValueEventListener(l); cont.invokeOnCancellation { r.removeEventListener(l) }
            }
        }
    }

    /** User: listen for new commands. */
    fun observeCommands(deviceId: String, onCommand: (Command) -> Unit): () -> Unit {
        val r = ref("commands/$deviceId")
        val l = object : ChildEventListener {
            override fun onChildAdded(s: DataSnapshot, p: String?) {
                val id = s.key ?: return
                // ignore stale commands (>2 min old) so reconnects don't replay history
                val ts = s.child("ts").getValue(Long::class.java) ?: 0
                if (System.currentTimeMillis() - ts > 120_000L) { s.ref.removeValue(); return }
                onCommand(Command(id, s.child("cmd").getValue(String::class.java) ?: "", s.child("arg").getValue(String::class.java) ?: "", ts,
                    s.child("token").getValue(String::class.java) ?: ""))
                s.ref.removeValue()
            }
            override fun onChildChanged(s: DataSnapshot, p: String?) {}
            override fun onChildRemoved(s: DataSnapshot) {}
            override fun onChildMoved(s: DataSnapshot, p: String?) {}
            override fun onCancelled(e: DatabaseError) {}
        }
        r.addChildEventListener(l)
        return { r.removeEventListener(l) }
    }

    fun writeResult(deviceId: String, r: Reply) {
        ref("commandResults/$deviceId/${r.id}").setValue(mapOf("ok" to r.ok, "msg" to r.msg, "hotspot" to r.hotspot, "ts" to System.currentTimeMillis()))
    }

    fun writeStatus(deviceId: String, battery: Int, charging: Boolean, hotspot: Boolean?, lastCmd: String? = null) {
        val m = mutableMapOf<String, Any?>("battery" to battery, "charging" to charging, "hotspot" to hotspot, "lastSeen" to ServerValue.TIMESTAMP)
        if (lastCmd != null) { m["lastCmd"] = lastCmd; m["lastCmdTs"] = System.currentTimeMillis() }
        ref("devices/$deviceId/status").updateChildren(m)
    }

    fun rename(deviceId: String, name: String) { ref("devices/$deviceId/meta/name").setValue(name) }
    fun setFcmToken(deviceId: String, t: String) { ref("devices/$deviceId/meta/fcmToken").setValue(t) }
}
