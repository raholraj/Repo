package com.remotehotspot.shared

import org.json.JSONObject

/** Command names shared by Bluetooth and Firebase transports. */
object Cmd {
    const val HOTSPOT_ON = "HOTSPOT_ON"
    const val HOTSPOT_OFF = "HOTSPOT_OFF"
    const val TOGGLE = "TOGGLE"
    const val GET_STATUS = "GET_STATUS"
    const val PING = "PING"
    const val RENAME = "RENAME"
    const val HEARTBEAT = "HEARTBEAT"
}

object Transport { const val BT = "BT"; const val FIREBASE = "FIREBASE"; const val OFFLINE = "OFFLINE" }

/** Fixed RFCOMM service UUID used by the User app server and Admin client. */
const val BT_SERVICE_UUID = "7f1c2b3a-5d4e-4a6b-9c8d-0e1f2a3b4c5d"
const val BT_SERVICE_NAME = "RemoteHotspotPro"
const val HEARTBEAT_MS = 30_000L
const val ONLINE_WINDOW_MS = 90_000L

data class Command(
    val id: String, val cmd: String, val arg: String = "",
    val ts: Long = System.currentTimeMillis(), val token: String = ""
) {
    fun toJson(): String = JSONObject().put("id", id).put("cmd", cmd).put("arg", arg).put("ts", ts).put("token", token).toString()
    companion object {
        fun fromJson(s: String): Command? = runCatching {
            val o = JSONObject(s)
            Command(o.getString("id"), o.getString("cmd"), o.optString("arg"), o.optLong("ts"), o.optString("token"))
        }.getOrNull()
    }
}

data class Reply(
    val id: String, val ok: Boolean, val msg: String = "",
    val hotspot: Boolean? = null, val battery: Int = -1, val charging: Boolean = false
) {
    fun toJson(): String = JSONObject().put("id", id).put("ok", ok).put("msg", msg)
        .put("hotspot", hotspot ?: JSONObject.NULL).put("battery", battery).put("charging", charging).toString()
    companion object {
        fun fromJson(s: String): Reply? = runCatching {
            val o = JSONObject(s)
            Reply(o.getString("id"), o.getBoolean("ok"), o.optString("msg"),
                if (o.isNull("hotspot")) null else o.getBoolean("hotspot"), o.optInt("battery", -1), o.optBoolean("charging"))
        }.getOrNull()
    }
}

/** Device snapshot as shown on an Admin card. */
data class DeviceInfo(
    val deviceId: String, val name: String = "", val model: String = "", val manufacturer: String = "",
    val battery: Int = -1, val charging: Boolean = false, val hotspot: Boolean? = null,
    val lastSeen: Long = 0, val btName: String = "", val token: String = "",
    val lastCmd: String = "", val lastCmdTs: Long = 0,
    val transport: String = Transport.OFFLINE
)

/** Exponential backoff helper: 2s, 4s, 8s ... capped at 5 min. */
fun backoffMs(attempt: Int): Long = (2_000L shl attempt.coerceIn(0, 7)).coerceAtMost(300_000L)
