# RemoteHotspot Controller Pro

Two apps + shared module:
- `admin/`  com.remotehotspot.admin  (controller)
- `user/`   com.remotehotspot.user   (controlled phone)
- `shared/` protocol, models, FirebaseRepo
- `firebase/` database rules + Cloud Function (FCM push)
- `java-alt/` Java versions of BtServer and the tile finder

## Folder structure
```
RemoteHotspotPro/
├─ settings.gradle.kts, build.gradle.kts, gradle.properties
├─ shared/src/main/java/.../shared/   Protocol.kt  FirebaseRepo.kt
├─ admin/src/main/java/.../admin/     MainActivity  AdminViewModel  AdminBt  HybridSender
├─ user/src/main/java/.../user/       MainActivity(wizard) CoreService BtServer
│                                     HotspotAccessibilityService CommandExecutor
│                                     OemUtils BootReceiver FcmService Prefs
├─ firebase/  database.rules.json  functions/index.js  firebase.json
└─ java-alt/  BtServerJava.java  HotspotTileFinder.java
```

## 1. Firebase setup
1. console.firebase.google.com -> create project.
2. Add TWO Android apps: `com.remotehotspot.admin` and `com.remotehotspot.user`.
   Download each `google-services.json` -> put in `admin/` and `user/` respectively.
3. Build > Authentication > Sign-in method > enable **Anonymous**.
4. Build > Realtime Database > Create database. Then Rules tab: paste `firebase/database.rules.json` and Publish.
5. (Instant push, optional but recommended) Upgrade to Blaze plan, then:
   `npm i -g firebase-tools && firebase login && firebase init` (use existing firebase.json) and
   `cd firebase/functions && npm install && cd .. && firebase deploy --only functions,database`
   Without the function the User app still receives commands via its always-open Realtime DB listener.

## 2. Build
Android Studio (Koala+), JDK 17. Open this folder, sync, then run `admin` and `user` configurations on two phones.
(Sideload; Google Play will not accept an Accessibility-based remote hotspot toggler.)

## 3. Test checklist
1. User phone: install `user`, complete steps 1-4 (permissions, battery, Accessibility 'Hotspot Control', OEM auto-start).
2. Pair the two phones once in system Bluetooth settings (needed for offline control only).
3. User phone: step 5 -> Generate code. Admin phone: Add device -> enter code. Card appears.
4. Keep User screen ON and unlocked -> tap ON / OFF / Toggle. Watch the badge: Bluetooth when near, Firebase otherwise.
5. Turn off User Bluetooth -> badge should fall back to Firebase. Turn off User Wi-Fi/data AND Bluetooth -> Offline.
6. Reboot the User phone -> service restarts by itself (BootReceiver) and the card returns online within ~30 s.

## Pairing flow
User creates `devices/{id}/meta` (+ random token) and `pairingCodes/{code}`. Admin writes `pairingClaims/{code}` = its anonymous UID.
User sees the claim, writes `meta/owner = adminUid`, deletes code. Rules then let ONLY that UID read status / write commands.
The token is also required in every Bluetooth and Firebase command.

## Known limits (be aware)
- Hotspot toggle works only with screen on + unlocked; Quick Settings layouts differ, so labels in
  `HotspotAccessibilityService.LABELS` may need an extra entry for your ROM (check logs).
- Layer 3 coordinates are learned automatically from the last successful tile click (no manual calibration UI).
- Hotspot state is read by reflection on a hidden API; if blocked, the tile's checked state is used.
- Admin connect/disconnect notifications fire only while the Admin app process is alive.
- Bluetooth needs the one-time system bonding; matching is by the User phone's Bluetooth name (keep names unique).
- Not compiled or run in this environment: expect to fix small compile/UI issues on first build.
