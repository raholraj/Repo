package com.remotehotspot.admin

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.remotehotspot.shared.*
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val vm: AdminViewModel by viewModels()

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) perms += listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)

        setContent {
            val dark = isSystemInDarkTheme()
            val scheme = if (dark) darkColorScheme(primary = Color(0xFF4DD0E1), secondary = Color(0xFF80CBC4))
            else lightColorScheme(primary = Color(0xFF00796B), secondary = Color(0xFF1565C0))
            MaterialTheme(colorScheme = scheme) { AdminScreen(vm) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminScreen(vm: AdminViewModel) {
    val ctx = LocalContext.current
    val devices by vm.devices.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    var showAdd by remember { mutableStateOf(false) }
    var showLogs by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<DeviceInfo?>(null) }
    var removing by remember { mutableStateOf<DeviceInfo?>(null) }

    LaunchedEffect(Unit) { vm.toast.collect { snack.showSnackbar(it) } }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(title = { Text("Hotspot Admin") }, actions = {
                IconButton({ vm.refresh() }) { Icon(Icons.Filled.Refresh, "Refresh") }
                IconButton({ showLogs = true }) { Icon(Icons.Filled.History, "Logs") }
                IconButton({ showSettings = true }) { Icon(Icons.Filled.Settings, "Settings") }
            })
        },
        floatingActionButton = { ExtendedFloatingActionButton({ showAdd = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Add device") }) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (devices.isNotEmpty()) Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.bulk(Cmd.HOTSPOT_ON) }, Modifier.weight(1f)) { Text("All ON") }
                OutlinedButton({ vm.bulk(Cmd.HOTSPOT_OFF) }, Modifier.weight(1f)) { Text("All OFF") }
            }
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                devices.isEmpty() -> EmptyState()
                else -> LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(devices, key = { it.deviceId }) { d ->
                        DeviceCard(d, d.deviceId in busy, { vm.command(d, it) }, { renaming = d }, { removing = d })
                    }
                }
            }
        }
    }

    if (showAdd) AddDialog(vm, { showAdd = false })
    renaming?.let { d -> RenameDialog(d.name, { renaming = null }) { vm.rename(d, it); renaming = null } }
    removing?.let { d ->
        AlertDialog(onDismissRequest = { removing = null }, title = { Text("Remove ${d.name}?") },
            text = { Text("It will be unpaired and you will lose control until it is paired again.") },
            confirmButton = { TextButton({ vm.unpair(d); removing = null }) { Text("Remove") } },
            dismissButton = { TextButton({ removing = null }) { Text("Cancel") } })
    }
    if (showLogs) AlertDialog(onDismissRequest = { showLogs = false }, title = { Text("Connection log") },
        text = { LazyColumn(Modifier.heightIn(max = 380.dp)) { if (logs.isEmpty()) item { Text("No events yet") }; items(logs) { Text(it, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) } } },
        confirmButton = { TextButton({
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, vm.exportLogs()), "Export logs")) }) { Text("Export") } },
        dismissButton = { TextButton({ showLogs = false }) { Text("Close") } })
    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Settings") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("RemoteHotspot Controller Pro v1.0.0\nHybrid control: Bluetooth first, Firebase fallback.")
            OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }) { Text("Bluetooth settings (pair phones once)") }
        } },
        confirmButton = { TextButton({ showSettings = false }) { Text("Close") } })
}

@Composable
private fun EmptyState() = Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
    Icon(Icons.Filled.WifiTethering, null, Modifier.size(96.dp), tint = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(16.dp))
    Text("No devices yet", style = MaterialTheme.typography.headlineSmall)
    Text("Install the User app on a phone, finish its setup, then tap Add device and enter the 6-digit code.", textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun DeviceCard(d: DeviceInfo, busy: Boolean, onCmd: (String) -> Unit, onRename: () -> Unit, onRemove: () -> Unit) {
    val online = d.transport != Transport.OFFLINE
    val color = when (d.transport) { Transport.BT -> Color(0xFF1E88E5); Transport.FIREBASE -> Color(0xFF00897B); else -> Color(0xFF9E9E9E) }
    val label = when (d.transport) { Transport.BT -> "Online (Bluetooth)"; Transport.FIREBASE -> "Online (Firebase)"; else -> "Offline" }
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().animateContentSize(), elevation = CardDefaults.cardElevation(4.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).background(color, CircleShape)); Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.name, style = MaterialTheme.typography.titleMedium)
                    Text("${d.manufacturer} ${d.model}", style = MaterialTheme.typography.bodySmall)
                }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Rename") }, { menu = false; onRename() })
                        DropdownMenuItem({ Text("Remove") }, { menu = false; onRemove() })
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip({}, { Text(label) }, leadingIcon = { Icon(if (d.transport == Transport.BT) Icons.Filled.Bluetooth else Icons.Filled.Cloud, null, Modifier.size(18.dp), tint = color) })
                AssistChip({}, { Text("Hotspot: " + when (d.hotspot) { true -> "ON"; false -> "OFF"; null -> "?" }) })
            }
            Text("Battery: ${if (d.battery >= 0) "${d.battery}%" else "?"}${if (d.charging) " ⚡ charging" else ""}", style = MaterialTheme.typography.bodyMedium)
            Text("Last seen: ${if (d.lastSeen > 0) DateFormat.getTimeInstance().format(Date(d.lastSeen)) else "never"}", style = MaterialTheme.typography.bodySmall)
            if (d.lastCmd.isNotEmpty()) Text("Last command: ${d.lastCmd} at ${DateFormat.getTimeInstance().format(Date(d.lastCmdTs))}", style = MaterialTheme.typography.bodySmall)
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ onCmd(Cmd.HOTSPOT_ON) }, Modifier.weight(1f), enabled = !busy) { Text("ON") }
                OutlinedButton({ onCmd(Cmd.HOTSPOT_OFF) }, Modifier.weight(1f), enabled = !busy) { Text("OFF") }
                FilledTonalButton({ onCmd(Cmd.TOGGLE) }, Modifier.weight(1f), enabled = !busy) { Text("Toggle") }
            }
            if (!online) Text("Offline: commands will still be tried over Firebase/Bluetooth.", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun AddDialog(vm: AdminViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var code by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onClose, title = { Text("Pair a device") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("1. Open the User app on the other phone and tap 'Generate code'.\n2. Enter the 6-digit code here.\n3. For offline (Bluetooth) control, also pair the two phones once in Bluetooth settings.")
            OutlinedTextField(code, { if (it.length <= 6) code = it.filter(Char::isDigit) }, label = { Text("6-digit code") }, singleLine = true)
            if (msg.isNotEmpty()) Text(msg)
            if (working) LinearProgressIndicator(Modifier.fillMaxWidth())
            TextButton({ ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }) { Text("Open Bluetooth settings") }
        } },
        confirmButton = { Button({
            working = true; msg = "Pairing..."
            vm.pair(code) { ok -> working = false; if (ok) onClose() else msg = "Failed. Check the code (valid 10 min) and internet." }
        }, enabled = code.length == 6 && !working) { Text("Pair") } },
        dismissButton = { TextButton(onClose) { Text("Cancel") } })
}

@Composable
private fun RenameDialog(current: String, onClose: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(current) }
    AlertDialog(onDismissRequest = onClose, title = { Text("Rename device") },
        text = { OutlinedTextField(t, { t = it }, singleLine = true) },
        confirmButton = { TextButton({ onOk(t) }) { Text("Save") } },
        dismissButton = { TextButton(onClose) { Text("Cancel") } })
}
