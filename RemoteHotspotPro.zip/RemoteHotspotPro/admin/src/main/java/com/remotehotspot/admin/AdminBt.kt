package com.remotehotspot.admin

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import com.remotehotspot.shared.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Bluetooth Classic client. Keeps one cached RFCOMM socket per device and reconnects lazily. */
@SuppressLint("MissingPermission")
class AdminBt(private val ctx: Context) {
    private val sockets = ConcurrentHashMap<String, BluetoothSocket>()
    private val locks = ConcurrentHashMap<String, Mutex>()

    private fun adapter() = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    /** The phone must be bonded once through system Bluetooth settings; we match it by Bluetooth name. */
    fun isBonded(btName: String) = runCatching { adapter()?.bondedDevices?.any { it.name == btName } == true }.getOrDefault(false)

    suspend fun send(dev: DeviceInfo, c: Command, timeoutMs: Long = 20_000L): Reply? = withContext(Dispatchers.IO) {
        val a = adapter() ?: return@withContext null
        if (!a.isEnabled || dev.btName.isBlank()) return@withContext null
        locks.getOrPut(dev.deviceId) { Mutex() }.withLock {
            repeat(2) { // second try = fresh socket
                var cached: BluetoothSocket? = sockets[dev.deviceId]
                var guard: Job? = null
                try {
                    if (cached == null || !cached.isConnected) {
                        val d = a.bondedDevices.firstOrNull { it.name == dev.btName } ?: return@withLock null
                        a.cancelDiscovery()
                        val fresh = d.createRfcommSocketToServiceRecord(UUID.fromString(BT_SERVICE_UUID))
                        cached = fresh
                        guard = launch { delay(8_000); runCatching { fresh.close() } }  // connect timeout
                        fresh.connect(); guard.cancel(); sockets[dev.deviceId] = fresh
                    }
                    val sock: BluetoothSocket = cached
                    guard = launch { delay(timeoutMs); runCatching { sock.close() } }  // read timeout
                    sock.outputStream.write((c.toJson() + "\n").toByteArray()); sock.outputStream.flush()
                    val line = sock.inputStream.bufferedReader().readLine()
                    guard.cancel()
                    return@withLock line?.let { Reply.fromJson(it) }
                } catch (e: Exception) {
                    guard?.cancel(); runCatching { cached?.close() }; sockets.remove(dev.deviceId)
                }
            }
            null
        }
    }

    fun closeAll() { sockets.values.forEach { runCatching { it.close() } }; sockets.clear() }
}
