package com.remotehotspot.admin

import com.remotehotspot.shared.*
import java.util.UUID

data class Outcome(val reply: Reply?, val transport: String)

/** Bluetooth first (fast, offline) -> Firebase fallback. Firebase first if Bluetooth recently failed. */
class HybridSender(private val bt: AdminBt, private val repo: FirebaseRepo) {
    suspend fun send(dev: DeviceInfo, cmd: String, arg: String = "", preferFirebase: Boolean = false): Outcome {
        val c = Command(UUID.randomUUID().toString().take(12), cmd, arg, token = dev.token)
        if (!preferFirebase) {
            bt.send(dev, c)?.let { return Outcome(it, Transport.BT) }
        }
        val r = runCatching { repo.sendCommand(dev.deviceId, c) }.getOrNull()
        if (r != null) return Outcome(r, Transport.FIREBASE)
        // Firebase failed/timeout: one last Bluetooth try if we skipped it
        if (preferFirebase) bt.send(dev, c)?.let { return Outcome(it, Transport.BT) }
        return Outcome(null, Transport.OFFLINE)
    }

    /** Cheap BT liveness probe used for the status badge. */
    suspend fun probeBt(dev: DeviceInfo): Boolean =
        bt.send(dev, Command(UUID.randomUUID().toString().take(12), Cmd.PING, token = dev.token), 6_000L) != null
}
