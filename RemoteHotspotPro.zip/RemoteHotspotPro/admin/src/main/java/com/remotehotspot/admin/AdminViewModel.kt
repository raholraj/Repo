package com.remotehotspot.admin

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.remotehotspot.shared.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.*

class AdminViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FirebaseRepo()
    private val bt = AdminBt(app)
    private val sender = HybridSender(bt, repo)

    private val raw = MutableStateFlow<List<DeviceInfo>>(emptyList())
    private val btOnline = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val loading = MutableStateFlow(true)
    val busy = MutableStateFlow<Set<String>>(emptySet())
    val logs = MutableStateFlow<List<String>>(emptyList())
    val toast = MutableSharedFlow<String>(extraBufferCapacity = 8)

    /** Devices with the final transport (BT > Firebase > Offline) merged in. */
    val devices: StateFlow<List<DeviceInfo>> = combine(raw, btOnline) { list, bo ->
        list.map { d -> d.copy(transport = when { bo[d.deviceId] == true -> Transport.BT; d.transport == Transport.FIREBASE -> Transport.FIREBASE; else -> Transport.OFFLINE }) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val lastTransport = mutableMapOf<String, String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    init {
        notifChannel()
        viewModelScope.launch {
            runCatching { repo.uid() }.onFailure { log("Sign-in failed: ${it.message}") }
            repo.observeDevices(repo.uid()).collect { raw.value = it; loading.value = false }
        }
        // BT probe + heartbeat-style refresh every 30 s
        viewModelScope.launch {
            while (isActive) { probeAll(); delay(HEARTBEAT_MS) }
        }
        // connect / disconnect notifications + history
        viewModelScope.launch {
            devices.collect { list ->
                list.forEach { d ->
                    val prev = lastTransport.put(d.deviceId, d.transport)
                    if (prev != null && prev != d.transport) {
                        log("${d.name}: $prev -> ${d.transport}")
                        if (prev == Transport.OFFLINE) notify(d, "${d.name} connected (${d.transport})")
                        if (d.transport == Transport.OFFLINE) notify(d, "${d.name} went offline")
                    }
                }
            }
        }
    }

    private suspend fun probeAll() = coroutineScope {
        val cur = raw.value
        val res = cur.map { d -> async { d.deviceId to (d.btName.isNotBlank() && sender.probeBt(d)) } }.awaitAll().toMap()
        btOnline.value = res
    }

    fun refresh() = viewModelScope.launch { toast.tryEmit("Refreshing..."); probeAll() }

    fun command(d: DeviceInfo, cmd: String) = viewModelScope.launch { runCommand(d, cmd) }

    private suspend fun runCommand(d: DeviceInfo, cmd: String) {
        busy.update { it + d.deviceId }
        val o = sender.send(d, cmd, preferFirebase = d.transport != Transport.BT)
        busy.update { it - d.deviceId }
        val msg = o.reply?.let { "${d.name}: ${if (it.ok) "OK" else "Failed"} - ${it.msg} via ${o.transport}" } ?: "${d.name}: unreachable (BT + Firebase failed)"
        log(msg); toast.tryEmit(msg)
    }

    /** Bulk: all devices that are currently online (BT or Firebase). */
    fun bulk(cmd: String) = viewModelScope.launch {
        val targets = devices.value.filter { it.transport != Transport.OFFLINE }
        if (targets.isEmpty()) { toast.tryEmit("No online devices"); return@launch }
        targets.map { d -> async { runCommand(d, cmd) } }.awaitAll()
    }

    fun rename(d: DeviceInfo, name: String) { if (name.isNotBlank()) { repo.rename(d.deviceId, name.trim()); log("Renamed ${d.name} -> $name") } }

    fun unpair(d: DeviceInfo) = viewModelScope.launch { runCatching { repo.unpair(d.deviceId) }.onSuccess { log("Unpaired ${d.name}") }.onFailure { toast.tryEmit("Unpair failed") } }

    fun pair(code: String, onDone: (Boolean) -> Unit) = viewModelScope.launch {
        val id = runCatching { repo.claimCode(code.trim()) }.getOrNull()
        log(if (id != null) "Paired device $id" else "Pairing failed for code $code")
        onDone(id != null)
    }

    fun exportLogs(): String = logs.value.joinToString("\n")
    fun isBonded(d: DeviceInfo) = bt.isBonded(d.btName)

    private fun log(m: String) { logs.update { (listOf("${fmt.format(Date())}  $m") + it).take(500) } }

    private fun notifChannel() {
        if (Build.VERSION.SDK_INT >= 26) getApplication<Application>().getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("conn", "Device connections", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun notify(d: DeviceInfo, text: String) {
        val app = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= 33 && app.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val n = NotificationCompat.Builder(app, "conn").setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setContentTitle("Hotspot Admin").setContentText(text).setAutoCancel(true).build()
        app.getSystemService(NotificationManager::class.java).notify(d.deviceId.hashCode(), n)
    }

    override fun onCleared() { bt.closeAll() }
}
