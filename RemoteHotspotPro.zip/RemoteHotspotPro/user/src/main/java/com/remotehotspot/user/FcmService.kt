package com.remotehotspot.user

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.remotehotspot.shared.FirebaseRepo

/** A high-priority FCM push just wakes the service; the command itself is read from Realtime Database. */
class FcmService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        val p = Prefs(this); p.fcmToken = token
        if (p.paired) FirebaseRepo().setFcmToken(p.deviceId, token)
    }
    override fun onMessageReceived(m: RemoteMessage) { CoreService.start(this) }
}
