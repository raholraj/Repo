package com.remotehotspot.user

import android.Manifest
import android.app.*
import android.bluetooth.BluetoothAdapter
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.remotehotspot.shared.*
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await

/**
 * Persistent foreground service:
 *  - heartbeat to Firebase every 30s (battery, hotspot, lastSeen)
 *  - Firebase command listener (+ FCM wake-ups)
 *  - Bluetooth RFCOMM server
 *  - restarts itself if the task is removed
 */
class CoreService : Service() {
    companion object {
        const val CH = "core"
        fun start(ctx: Context) {
            val i = Intent(ctx, CoreService::class.java)
            runCatching { ContextCompat.startForegroundService(ctx, i) }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val repo by lazy { FirebaseRepo() }
    private var bt: BtServer? = null
    private var stopListening: (() -> Unit)? = null
    private var started = false

    private val btReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1) == BluetoothAdapter.STATE_ON) { bt?.stop(); bt = BtServer(this@CoreService, repo).also { it.start() } }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Device connection", NotificationManager.IMPORTANCE_DEFAULT).apply { setSound(null, null); enableVibration(false) })
        val n = NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Hotspot Device active").setContentText("Connected and ready for Admin commands")
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        runCatching {
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(1, n)
        }
        registerReceiver(btReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!started) { started = true; scope.launch { run() } }
        return START_STICKY
    }

    private suspend fun run() {
        val prefs = Prefs(this)
        var attempt = 0
        while (scope.isActive) {
            try {
                repo.uid()                                   // anonymous sign-in (cached after first time)
                if (!prefs.paired) { delay(5000); continue } // idle until pairing completes
                if (bt == null && btAllowed()) bt = BtServer(this, repo).also { it.start() }
                if (stopListening == null) stopListening = repo.observeCommands(prefs.deviceId) { c -> scope.launch { handle(c) } }
                runCatching { FirebaseMessaging.getInstance().token.await().let { prefs.fcmToken = it; repo.setFcmToken(prefs.deviceId, it) } }
                attempt = 0
                while (scope.isActive && prefs.paired) {         // heartbeat loop
                    val (b, c) = CommandExecutor.battery(this)
                    repo.writeStatus(prefs.deviceId, b, c, HotspotAccessibilityService.isHotspotOn(this))
                    delay(HEARTBEAT_MS)
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { HotspotAccessibilityService.log("core loop: ${e.message}"); delay(backoffMs(attempt++)) }
        }
    }

    private suspend fun handle(c: Command) {
        val reply = CommandExecutor.run(this, c, repo)
        repo.writeResult(Prefs(this).deviceId, reply)
    }

    private fun btAllowed() = Build.VERSION.SDK_INT < 31 || ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    /** Swiped away from Recents -> schedule a restart. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val pi = PendingIntent.getService(this, 7, Intent(this, CoreService::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_ONE_SHOT)
        (getSystemService(ALARM_SERVICE) as AlarmManager).set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 2000, pi)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(btReceiver) }; bt?.stop(); stopListening?.invoke(); scope.cancel()
        // ask the system to bring us back
        start(applicationContext)
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
