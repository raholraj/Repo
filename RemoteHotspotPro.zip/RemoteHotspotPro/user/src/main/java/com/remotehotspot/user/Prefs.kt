package com.remotehotspot.user

import android.content.Context
import java.util.UUID

/** Tiny wrapper over SharedPreferences. Device ID is generated once and never changes. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("rh_user", Context.MODE_PRIVATE)
    val deviceId: String get() = sp.getString("deviceId", null) ?: UUID.randomUUID().toString().also { sp.edit().putString("deviceId", it).apply() }
    var token: String get() = sp.getString("token", "") ?: ""; set(v) = sp.edit().putString("token", v).apply()
    var paired: Boolean get() = sp.getBoolean("paired", false); set(v) = sp.edit().putBoolean("paired", v).apply()
    var tileX: Int get() = sp.getInt("tileX", -1); set(v) = sp.edit().putInt("tileX", v).apply()
    var tileY: Int get() = sp.getInt("tileY", -1); set(v) = sp.edit().putInt("tileY", v).apply()
    var fcmToken: String get() = sp.getString("fcm", "") ?: ""; set(v) = sp.edit().putString("fcm", v).apply()
}
