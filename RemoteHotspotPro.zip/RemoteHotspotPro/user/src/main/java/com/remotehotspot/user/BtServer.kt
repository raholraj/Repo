package com.remotehotspot.user

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import com.remotehotspot.shared.*
import kotlinx.coroutines.runBlocking
import java.util.UUID

/**
 * Bluetooth Classic RFCOMM server. Accepts the paired Admin, serves newline-delimited JSON commands.
 * Auto-restarts with exponential backoff if the socket dies or Bluetooth is toggled.
 */
@SuppressLint("MissingPermission")
class BtServer(private val ctx: Context, private val repo: FirebaseRepo) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var server: BluetoothServerSocket? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "bt-server").also { it.isDaemon = true; it.start() }
    }

    fun stop() { running = false; runCatching { server?.close() }; thread?.interrupt() }

    private fun loop() {
        var attempt = 0
        while (running) {
            try {
                val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                if (adapter == null || !adapter.isEnabled) { Thread.sleep(5000); continue }
                server = adapter.listenUsingRfcommWithServiceRecord(BT_SERVICE_NAME, UUID.fromString(BT_SERVICE_UUID))
                attempt = 0
                while (running) {
                    val sock = server!!.accept()          // blocks until Admin connects
                    Thread({ serve(sock) }, "bt-client").also { it.isDaemon = true }.start()
                }
            } catch (e: Exception) {
                HotspotAccessibilityService.log("BT server error: ${e.message}")
                runCatching { server?.close() }
                if (!running) return
                try { Thread.sleep(backoffMs(attempt++)) } catch (_: InterruptedException) { return }
            }
        }
    }

    private fun serve(sock: BluetoothSocket) {
        sock.use {
            val input = it.inputStream.bufferedReader(); val out = it.outputStream
            while (running) {
                val line = input.readLine() ?: break
                val cmd = Command.fromJson(line)
                val reply = if (cmd == null) Reply("?", false, "Bad JSON") else runBlocking { CommandExecutor.run(ctx, cmd, repo) }
                out.write((reply.toJson() + "\n").toByteArray()); out.flush()
            }
        }
    }
}
