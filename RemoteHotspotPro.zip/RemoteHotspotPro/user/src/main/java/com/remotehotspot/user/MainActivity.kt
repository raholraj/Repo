package com.remotehotspot.user

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.text.TextUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.remotehotspot.shared.FirebaseRepo
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        CoreService.start(this)
        setContent {
            val dark = isSystemInDarkTheme()
            val scheme = if (dark) darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF4DD0E1)) else lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF00796B))
            MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { Wizard() } }
        }
    }
}

private fun a11yEnabled(ctx: Context): Boolean {
    val me = ComponentName(ctx, HotspotAccessibilityService::class.java).flattenToString()
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return TextUtils.SimpleStringSplitter(':').apply { setString(s) }.any { it.equals(me, true) }
}

private fun btPermsGranted(ctx: Context) = Build.VERSION.SDK_INT < 31 ||
    listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE)
        .all { ctx.checkSelfPermission(it) == android.content.pm.PackageManager.PERMISSION_GRANTED }

private fun notifGranted(ctx: Context) = Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED

private fun batteryIgnored(ctx: Context) = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)

@SuppressLint("MissingPermission", "BatteryLife")
@Composable
private fun Wizard() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val repo = remember { FirebaseRepo() }
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var code by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf(if (prefs.paired) "Paired with Admin" else "") }
    var paired by remember { mutableStateOf(prefs.paired) }
    val oem = remember { OemUtils.detect() }

    // refresh step states every time the user returns from a settings screen
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++; CoreService.start(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Device setup", fontSize = 28.sp, style = MaterialTheme.typography.headlineMedium)
        Text("Finish these steps once. After that this phone connects to your Admin automatically.", style = MaterialTheme.typography.bodyMedium)

        @Suppress("UNUSED_EXPRESSION") tick
        StepCard("1. Permissions", "Bluetooth + notifications", btPermsGranted(ctx) && notifGranted(ctx), "Grant") {
            val p = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 31) p += listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE)
            if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
            if (p.isNotEmpty()) permLauncher.launch(p.toTypedArray())
        }
        StepCard("2. Ignore battery optimization", "Keeps the service alive in the background", batteryIgnored(ctx), "Allow") {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
        }
        StepCard("3. Accessibility service", "Required to tap the hotspot tile. Find 'Hotspot Control' and turn it on.", a11yEnabled(ctx), "Open") {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        StepCard("4. Auto-start / background", OemUtils.instructions(oem), null, "Open settings") { OemUtils.openAutoStart(ctx) }

        Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(4.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("5. Pair with Admin", style = MaterialTheme.typography.titleMedium)
                if (paired) Text("✓ Paired. Nothing more to do — you can close this app.")
                else {
                    Text("Tap Generate, then type the code in the Admin app (valid 10 minutes).")
                    code?.let { Text(it, fontSize = 40.sp, style = MaterialTheme.typography.displaySmall) }
                    if (status.isNotEmpty()) Text(status)
                    Button(onClick = {
                        scope.launch {
                            runCatching {
                                status = "Creating code..."
                                val btName = runCatching { BluetoothAdapter.getDefaultAdapter()?.name ?: "" }.getOrDefault("")
                                val meta = mapOf("name" to "${Build.MANUFACTURER} ${Build.MODEL}", "model" to Build.MODEL,
                                    "manufacturer" to Build.MANUFACTURER, "btName" to btName)
                                val c = repo.createPairingCode(prefs.deviceId, meta); code = c; status = "Waiting for Admin..."
                                val admin = repo.awaitClaim(c, prefs.deviceId)
                                if (admin != null) {
                                    prefs.token = repo.ref("devices/${prefs.deviceId}/meta/token").get().await().getValue(String::class.java) ?: ""
                                    prefs.paired = true; paired = true; status = "Paired!"; CoreService.start(ctx)
                                } else status = "Timed out. Generate a new code."
                            }.onFailure { status = "Error: ${it.message}" }
                        }
                    }) { Text(if (code == null) "Generate code" else "New code") }
                }
            }
        }
    }
}

@Composable
private fun StepCard(title: String, body: String, done: Boolean?, action: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(4.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (done != null) Icon(if (done) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked, null,
                    tint = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            Text(body, style = MaterialTheme.typography.bodyMedium)
            if (done != true) FilledTonalButton(onClick = onClick) { Text(action) }
        }
    }
}
