// Sends a high-priority FCM data message to the User device whenever the Admin writes a command.
const { onValueCreated } = require("firebase-functions/v2/database");
const admin = require("firebase-admin");
admin.initializeApp();

exports.onCommand = onValueCreated("/commands/{deviceId}/{cmdId}", async (event) => {
  const { deviceId, cmdId } = event.params;
  const snap = await admin.database().ref(`devices/${deviceId}/meta/fcmToken`).get();
  const token = snap.val();
  if (!token) return;
  await admin.messaging().send({
    token,
    data: { type: "cmd", cmdId },
    android: { priority: "high", ttl: 60000 },
  });
});
