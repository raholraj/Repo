package com.remotehotspot.user;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;

/** Java version of the tile-search + click layers (layers 1 & 2) used by HotspotAccessibilityService. */
public final class HotspotTileFinder {
    private static final String[] LABELS = {"mobile hotspot", "personal hotspot", "wi-fi hotspot", "wifi hotspot",
            "portable hotspot", "portable wi-fi hotspot", "hotspot", "tethering", "wlan hotspot", "mobile ap"};
    private static final String[] ID_HINTS = {"hotspot", "tether", "wifi_ap", "softap"};

    public static AccessibilityNodeInfo find(AccessibilityNodeInfo root) {
        if (root == null) return null;
        List<AccessibilityNodeInfo> all = new ArrayList<>(); collect(root, all, 0);
        for (String label : LABELS) for (AccessibilityNodeInfo n : all) {
            CharSequence t = n.getText(), d = n.getContentDescription();
            if ((t != null && t.toString().toLowerCase().contains(label)) || (d != null && d.toString().toLowerCase().contains(label))) return n;
        }
        for (AccessibilityNodeInfo n : all) {
            String id = n.getViewIdResourceName(); if (id == null) continue;
            id = id.toLowerCase(); for (String h : ID_HINTS) if (id.contains(h)) return n;
        }
        return null;
    }

    private static void collect(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 30) return; out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), out, depth + 1);
    }

    /** Clicks the node or the nearest clickable ancestor; returns bounds center via out[0..1] on success. */
    public static boolean click(AccessibilityNodeInfo n, int[] out) {
        Rect r = new Rect(); n.getBoundsInScreen(r); out[0] = r.centerX(); out[1] = r.centerY();
        AccessibilityNodeInfo c = n; int hops = 0;
        while (c != null && hops++ < 6) { if (c.isClickable() && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.getParent(); }
        return false;
    }
}
