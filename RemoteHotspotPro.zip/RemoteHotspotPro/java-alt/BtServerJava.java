package com.remotehotspot.user;

import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.content.Context;
import java.io.*;
import java.util.UUID;

/** Java equivalent of BtServer.kt (RFCOMM server with exponential-backoff restart). Copy into user/src/main/java and delete BtServer.kt to use. */
@SuppressLint("MissingPermission")
public class BtServerJava {
    public interface Handler { String onLine(String jsonLine); }

    private static final String UUID_STR = "7f1c2b3a-5d4e-4a6b-9c8d-0e1f2a3b4c5d";
    private final Context ctx; private final Handler handler;
    private volatile boolean running; private BluetoothServerSocket server;

    public BtServerJava(Context ctx, Handler h) { this.ctx = ctx.getApplicationContext(); this.handler = h; }

    public void start() {
        if (running) return; running = true;
        Thread t = new Thread(this::loop, "bt-server"); t.setDaemon(true); t.start();
    }
    public void stop() { running = false; try { if (server != null) server.close(); } catch (IOException ignored) {} }

    private void loop() {
        int attempt = 0;
        while (running) {
            try {
                BluetoothAdapter a = ((BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();
                if (a == null || !a.isEnabled()) { Thread.sleep(5000); continue; }
                server = a.listenUsingRfcommWithServiceRecord("RemoteHotspotPro", UUID.fromString(UUID_STR));
                attempt = 0;
                while (running) { final BluetoothSocket s = server.accept(); new Thread(() -> serve(s)).start(); }
            } catch (Exception e) {
                try { if (server != null) server.close(); } catch (IOException ignored) {}
                if (!running) return;
                try { Thread.sleep(Math.min(300_000L, 2000L << Math.min(attempt++, 7))); } catch (InterruptedException ie) { return; }
            }
        }
    }

    private void serve(BluetoothSocket s) {
        try (BluetoothSocket sock = s;
             BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
             OutputStream out = sock.getOutputStream()) {
            String line;
            while (running && (line = in.readLine()) != null) { out.write((handler.onLine(line) + "\n").getBytes()); out.flush(); }
        } catch (IOException ignored) {}
    }
}
